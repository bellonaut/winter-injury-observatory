"""
FastAPI Application for Winter Injury Observatory

Provides prediction endpoints, model metrics, and health checks.
"""
import os
import logging
from contextlib import asynccontextmanager
from typing import List, Optional

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import mlflow
import pandas as pd
from pydantic import BaseModel, Field

from api.models import PredictionRequest, PredictionResponse, BatchPredictionRequest
from api.services import ModelService, DatabaseService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global model service
model_service: Optional[ModelService] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifecycle management"""
    global model_service
    
    # Startup
    logger.info("Loading ML model...")
    model_service = ModelService()
    await model_service.load_model()
    
    yield
    
    # Shutdown
    logger.info("Shutting down...")


app = FastAPI(
    title="Winter Injury Risk Observatory API",
    description="ML-powered winter injury risk prediction for Edmonton",
    version="1.0.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()


def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Verify JWT token"""
    # Simplified - in production use proper JWT verification
    if credentials.credentials != os.getenv("API_SECRET_KEY", "dev-secret"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
        )
    return credentials


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "Winter Injury Risk Observatory API",
        "version": "1.0.0",
        "status": "operational"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    health_status = {
        "status": "healthy",
        "model_loaded": model_service is not None and model_service.model is not None,
        "database": "unknown"
    }
    
    # Check database connection
    try:
        db_service = DatabaseService()
        health_status["database"] = "connected" if db_service.check_connection() else "disconnected"
    except Exception as e:
        health_status["database"] = f"error: {str(e)}"
    
    return health_status


@app.post("/predict", response_model=PredictionResponse)
async def predict(
    request: PredictionRequest,
    credentials: HTTPAuthorizationCredentials = Depends(verify_token)
):
    """
    Make a single prediction for injury risk.
    
    Returns risk probability and risk level classification.
    """
    if model_service is None or model_service.model is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model not loaded"
        )
    
    try:
        # Convert request to DataFrame
        features = request.dict()
        df = pd.DataFrame([features])
        
        # Make prediction
        prediction = model_service.predict(df)
        
        return PredictionResponse(
            prediction=int(prediction["prediction"]),
            probability=float(prediction["probability"]),
            risk_level=prediction["risk_level"],
            features=features
        )
    
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Prediction failed: {str(e)}"
        )


@app.post("/batch_predict")
async def batch_predict(
    request: BatchPredictionRequest,
    credentials: HTTPAuthorizationCredentials = Depends(verify_token)
):
    """
    Make batch predictions for multiple inputs.
    
    Returns list of predictions.
    """
    if model_service is None or model_service.model is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model not loaded"
        )
    
    try:
        # Convert requests to DataFrame
        df = pd.DataFrame([r.dict() for r in request.predictions])
        
        # Make predictions
        predictions = model_service.batch_predict(df)
        
        return {
            "count": len(predictions),
            "predictions": predictions
        }
    
    except Exception as e:
        logger.error(f"Batch prediction error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Batch prediction failed: {str(e)}"
        )


@app.get("/model/metrics")
async def get_model_metrics(
    credentials: HTTPAuthorizationCredentials = Depends(verify_token)
):
    """Get current model performance metrics"""
    if model_service is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model service not available"
        )
    
    try:
        metrics = model_service.get_metrics()
        return metrics
    except Exception as e:
        logger.error(f"Error fetching metrics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch metrics: {str(e)}"
        )


@app.get("/model/info")
async def get_model_info():
    """Get model information"""
    if model_service is None or model_service.model is None:
        return {"status": "no_model_loaded"}
    
    return {
        "model_version": model_service.model_version,
        "model_uri": model_service.model_uri,
        "loaded_at": model_service.loaded_at.isoformat() if model_service.loaded_at else None,
        "feature_count": len(model_service.feature_names) if model_service.feature_names else 0
    }


@app.post("/model/reload")
async def reload_model(
    credentials: HTTPAuthorizationCredentials = Depends(verify_token)
):
    """Reload the model from MLflow"""
    if model_service is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Model service not available"
        )
    
    try:
        await model_service.load_model(force_reload=True)
        return {"status": "success", "message": "Model reloaded successfully"}
    except Exception as e:
        logger.error(f"Model reload error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Model reload failed: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "api.main:app",
        host=os.getenv("API_HOST", "0.0.0.0"),
        port=int(os.getenv("API_PORT", 8000)),
        reload=os.getenv("API_RELOAD", "false").lower() == "true",
        workers=int(os.getenv("API_WORKERS", 1))
    )
