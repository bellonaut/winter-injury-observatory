"""Service layer for API"""
import os
import logging
from datetime import datetime
from typing import Dict, List, Optional

import mlflow
import pandas as pd
from sqlalchemy import create_engine

logger = logging.getLogger(__name__)


class ModelService:
    """ML model service"""
    
    def __init__(self):
        self.model = None
        self.model_version = None
        self.model_uri = None
        self.feature_names = None
        self.loaded_at = None
        
        # MLflow setup
        mlflow.set_tracking_uri(os.getenv("MLFLOW_TRACKING_URI", "http://localhost:5000"))
    
    async def load_model(self, force_reload: bool = False):
        """Load model from MLflow"""
        if self.model is not None and not force_reload:
            logger.info("Model already loaded")
            return
        
        try:
            # Get production model
            model_name = os.getenv("MODEL_NAME", "winter-injury-risk")
            model_version = os.getenv("MODEL_VERSION", "production")
            
            if model_version == "production":
                self.model_uri = f"models:/{model_name}/Production"
            else:
                self.model_uri = f"models:/{model_name}/{model_version}"
            
            logger.info(f"Loading model from {self.model_uri}")
            self.model = mlflow.xgboost.load_model(self.model_uri)
            self.model_version = model_version
            self.loaded_at = datetime.now()
            
            logger.info(f"Model loaded successfully: {model_version}")
        
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise
    
    def predict(self, df: pd.DataFrame) -> Dict:
        """Make single prediction"""
        if self.model is None:
            raise ValueError("Model not loaded")
        
        # Make prediction
        prediction = self.model.predict(df)[0]
        probability = self.model.predict_proba(df)[0, 1]
        
        # Determine risk level
        if probability < 0.3:
            risk_level = "low"
        elif probability < 0.6:
            risk_level = "medium"
        elif probability < 0.8:
            risk_level = "high"
        else:
            risk_level = "critical"
        
        return {
            "prediction": int(prediction),
            "probability": float(probability),
            "risk_level": risk_level
        }
    
    def batch_predict(self, df: pd.DataFrame) -> List[Dict]:
        """Make batch predictions"""
        if self.model is None:
            raise ValueError("Model not loaded")
        
        predictions = self.model.predict(df)
        probabilities = self.model.predict_proba(df)[:, 1]
        
        results = []
        for pred, prob in zip(predictions, probabilities):
            if prob < 0.3:
                risk_level = "low"
            elif prob < 0.6:
                risk_level = "medium"
            elif prob < 0.8:
                risk_level = "high"
            else:
                risk_level = "critical"
            
            results.append({
                "prediction": int(pred),
                "probability": float(prob),
                "risk_level": risk_level
            })
        
        return results
    
    def get_metrics(self) -> Dict:
        """Get model metrics from MLflow"""
        try:
            client = mlflow.tracking.MlflowClient()
            
            # Get latest run for the model
            runs = client.search_runs(
                experiment_ids=["0"],  # Adjust based on your experiment
                order_by=["start_time DESC"],
                max_results=1
            )
            
            if runs:
                run = runs[0]
                metrics = run.data.metrics
                return {
                    "accuracy": metrics.get("accuracy"),
                    "precision": metrics.get("precision"),
                    "recall": metrics.get("recall"),
                    "f1": metrics.get("f1"),
                    "roc_auc": metrics.get("roc_auc"),
                }
            else:
                return {}
        
        except Exception as e:
            logger.error(f"Error fetching metrics: {e}")
            return {}


class DatabaseService:
    """Database service"""
    
    def __init__(self):
        self.engine = create_engine(os.getenv("DATABASE_URL"))
    
    def check_connection(self) -> bool:
        """Check database connection"""
        try:
            with self.engine.connect() as conn:
                conn.execute("SELECT 1")
            return True
        except Exception:
            return False
    
    def get_recent_predictions(self, limit: int = 100) -> pd.DataFrame:
        """Get recent predictions from database"""
        query = f"SELECT * FROM predictions ORDER BY timestamp DESC LIMIT {limit}"
        return pd.read_sql(query, self.engine)
